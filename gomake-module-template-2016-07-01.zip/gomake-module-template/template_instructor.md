# Module Number: Module Title (Instructor)


Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.

![MacDown logo](placeholder-690x360.png)

## KUD (Know-Understand-Do)

### Things Students Will Know
* Item 1
* Item 2
* Item 3

### Things Students Will Understand
* Item 1
* Item 2
* Item 3

### Things Students Will Do
* Item 1
* Item 2
* Item 3

## Driving Question

### Driving Question goes here
Summary and lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 

> INSTRUCTOR NOTE: 
> Some items for the driving question:
> 
> * Consectetur adipiscing elit
> * Excepteur sint occaecat

## Entry Event

### Description of entry event here.
* Event detail 1
* Event detail 2
* Event detail 3

## Products

### Product created by students 1 listed here.
Description and lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 

### Product 2 listed here.
Description and lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. 

## Things They'll Need

### Parts
* Item 1
* Item 2
* Item 3

![MacDown logo](placeholder-690x360.png)

### Equipment
* Item 1
* Item 2
* Item 3

> WARNING: Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.

![MacDown logo](placeholder-690x360.png)

## Session Schedule

### Session 1: Session 1 Goal
Everything you need to know to lead Session 1. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.


### Session 2: Session 2 Goal
Everything you need to know to lead Session 2. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.


## Reflection Methods

### Record Your Thoughts

### Feedback


## Making Products Public
How students' products will be made public and who students will interact with during the publishing process.